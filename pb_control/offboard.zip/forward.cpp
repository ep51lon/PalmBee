#include <px4_msgs/msg/trajectory_setpoint.hpp>
#include <rclcpp/rclcpp.hpp>
#include <cmath>  // Untuk fungsi sin dan cos

using namespace std::chrono_literals;
using namespace px4_msgs::msg;

class OffboardControl : public rclcpp::Node
{
public:
    OffboardControl() : Node("offboard_control")
    {
        // Inisialisasi publisher
        trajectory_setpoint_publisher_ = this->create_publisher<TrajectorySetpoint>("/fmu/in/trajectory_setpoint", 10);

        // Variabel untuk kontrol gerakan linear
        offboard_setpoint_counter_ = 0;

        auto timer_callback = [this]() -> void {
            // Publish trajectory (gerakan maju)
            publish_trajectory_setpoint();

            // Stop the counter after reaching 11
            if (offboard_setpoint_counter_ < 11) {
                offboard_setpoint_counter_++;
            }
        };

        // Timer untuk memanggil callback setiap 100ms
        timer_ = this->create_wall_timer(100ms, timer_callback);
    }

private:
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<TrajectorySetpoint>::SharedPtr trajectory_setpoint_publisher_;
    uint64_t offboard_setpoint_counter_;

    void publish_trajectory_setpoint();
};

/**
 * @brief Publish a trajectory setpoint untuk gerakan maju
 */
void OffboardControl::publish_trajectory_setpoint()
{
    // Koordinat untuk posisi X, Y, dan Z
    double x = 5.0;  // Posisi X (m)
    double y = 0.0;  // Posisi Y (m) tetap
    double z = NAN; // Posisi Z (m) tetap pada ketinggian 5 meter

    // Trajectory setpoint untuk maju
    TrajectorySetpoint msg{};
    msg.position = {static_cast<float>(x), static_cast<float>(y), static_cast<float>(z)};
    msg.yaw = 0.0f;  // Mengatur yaw agar tetap di arah yang sama (0 radian)
    msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
    trajectory_setpoint_publisher_->publish(msg);
}

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<OffboardControl>());
    rclcpp::shutdown();
    return 0;
}
