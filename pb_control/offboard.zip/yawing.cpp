#include <px4_msgs/msg/offboard_control_mode.hpp>
#include <px4_msgs/msg/trajectory_setpoint.hpp>
#include <px4_msgs/msg/vehicle_command.hpp>
#include <px4_msgs/msg/vehicle_control_mode.hpp>
#include <rclcpp/rclcpp.hpp>
#include <stdint.h>

#include <chrono>
#include <iostream>
#include <cmath>

using namespace std::chrono;
using namespace std::chrono_literals;
using namespace px4_msgs::msg;

class OffboardControl : public rclcpp::Node
{
public:
	OffboardControl() : Node("offboard_control")
	{
		offboard_control_mode_publisher_ = this->create_publisher<OffboardControlMode>("/fmu/in/offboard_control_mode", 10);
		trajectory_setpoint_publisher_ = this->create_publisher<TrajectorySetpoint>("/fmu/in/trajectory_setpoint", 10);
		vehicle_command_publisher_ = this->create_publisher<VehicleCommand>("/fmu/in/vehicle_command", 10);

		offboard_setpoint_counter_ = 0;
		rotation_step_counter_ = 0;
		yaw_rotation_complete_ = false;
		current_yaw_ = 3.14; // Start with yaw at 180 degrees

		auto timer_callback = [this]() -> void {
			if (offboard_setpoint_counter_ == 10) {
				// Change to Offboard mode after 10 setpoints
				this->publish_vehicle_command(VehicleCommand::VEHICLE_CMD_DO_SET_MODE, 1, 6);

				// Arm the vehicle
				this->arm();
			}

			if (offboard_setpoint_counter_ < 10) {
				// Hovering phase
				publish_offboard_control_mode();
				publish_hovering_setpoint();
				offboard_setpoint_counter_++;
			} else if (!yaw_rotation_complete_) {
				// Perform yaw rotation in steps
				publish_offboard_control_mode();
				perform_yaw_rotation();
			}
		};
		timer_ = this->create_wall_timer(100ms, timer_callback);
	}

	void arm();
	void disarm();

private:
	rclcpp::TimerBase::SharedPtr timer_;

	rclcpp::Publisher<OffboardControlMode>::SharedPtr offboard_control_mode_publisher_;
	rclcpp::Publisher<TrajectorySetpoint>::SharedPtr trajectory_setpoint_publisher_;
	rclcpp::Publisher<VehicleCommand>::SharedPtr vehicle_command_publisher_;

	std::atomic<uint64_t> timestamp_;   //!< common synced timestamped

	uint64_t offboard_setpoint_counter_;   //!< counter for the number of setpoints sent
	uint64_t rotation_step_counter_;       //!< counter for the yaw rotation steps
	bool yaw_rotation_complete_;           //!< flag to indicate yaw rotation is complete
	double current_yaw_;                   //!< current yaw angle in radians

	void publish_offboard_control_mode();
	void publish_hovering_setpoint();
	void perform_yaw_rotation();
	void publish_vehicle_command(uint16_t command, float param1 = 0.0, float param2 = 0.0);
};

void OffboardControl::arm()
{
	publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0);
	RCLCPP_INFO(this->get_logger(), "Arm command sent");
}

void OffboardControl::disarm()
{
	publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 0.0);
	RCLCPP_INFO(this->get_logger(), "Disarm command sent");
}

void OffboardControl::publish_offboard_control_mode()
{
	OffboardControlMode msg{};
	msg.position = true;
	msg.velocity = false;
	msg.acceleration = false;
	msg.attitude = false;
	msg.body_rate = false;
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	offboard_control_mode_publisher_->publish(msg);
}

void OffboardControl::publish_hovering_setpoint()
{
	TrajectorySetpoint msg{};
	msg.position = {0.0, 0.0, -15.0};
	msg.yaw = current_yaw_; // Hover with the current yaw angle
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	trajectory_setpoint_publisher_->publish(msg);
}

void OffboardControl::perform_yaw_rotation()
{
	// Perform slow yaw rotation over 3 full cycles (3 * 2 * PI radians)
	constexpr double yaw_step = 0.05; // Increment per step in radians
	constexpr double total_yaw = 3 * 2 * M_PI; // Total yaw rotation in radians

	if (rotation_step_counter_ * yaw_step < total_yaw) {
		current_yaw_ += yaw_step;
		if (current_yaw_ > M_PI) {
			current_yaw_ -= 2 * M_PI; // Keep yaw within [-PI, PI]
		}

		TrajectorySetpoint msg{};
		msg.position = {0.0, 0.0, -15.0}; // Maintain current position
		msg.yaw = current_yaw_;
		msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
		trajectory_setpoint_publisher_->publish(msg);

		rotation_step_counter_++;
		RCLCPP_INFO(this->get_logger(), "Yaw rotation step: %d, Current yaw: %.2f", rotation_step_counter_, current_yaw_);
	} else {
		yaw_rotation_complete_ = true;
		RCLCPP_INFO(this->get_logger(), "Yaw rotation complete");
	}
}

void OffboardControl::publish_vehicle_command(uint16_t command, float param1, float param2)
{
	VehicleCommand msg{};
	msg.param1 = param1;
	msg.param2 = param2;
	msg.command = command;
	msg.target_system = 1;
	msg.target_component = 1;
	msg.source_system = 1;
	msg.source_component = 1;
	msg.from_external = true;
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	vehicle_command_publisher_->publish(msg);
}

int main(int argc, char *argv[])
{
	std::cout << "Starting offboard control node..." << std::endl;
	setvbuf(stdout, NULL, _IONBF, BUFSIZ);
	rclcpp::init(argc, argv);
	rclcpp::spin(std::make_shared<OffboardControl>());
	rclcpp::shutdown();
	return 0;
}
