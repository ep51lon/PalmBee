#include <px4_msgs/msg/offboard_control_mode.hpp>
#include <px4_msgs/msg/trajectory_setpoint.hpp>
#include <px4_msgs/msg/vehicle_command.hpp>
#include <px4_msgs/msg/vehicle_odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <stdint.h>

#include <chrono>
#include <iostream>

using namespace std::chrono;
using namespace std::chrono_literals;
using namespace px4_msgs::msg;

class OffboardControl : public rclcpp::Node
{
public:
	OffboardControl() : Node("offboard_control")
	{
		offboard_control_mode_publisher_ = this->create_publisher<OffboardControlMode>("/fmu/in/offboard_control_mode", 10);
		trajectory_setpoint_publisher_ = this->create_publisher<TrajectorySetpoint>("/fmu/in/trajectory_setpoint", 10);
		vehicle_command_publisher_ = this->create_publisher<VehicleCommand>("/fmu/in/vehicle_command", 10);

		// Subscriber for vehicle odometry with best effort QoS
		vehicle_odometry_subscriber_ = this->create_subscription<VehicleOdometry>(
			"/fmu/out/vehicle_odometry", rclcpp::QoS(10).best_effort(),
			[this](const VehicleOdometry::SharedPtr msg) {
				current_altitude_ = msg->position[2]; // Update current_altitude_ with z position
			});

		// Timer callback for landing sequence
		landing_timer_ = this->create_wall_timer(500ms, [this]() { smooth_landing(); });
	}

	void arm();
	void disarm();
	void smooth_landing();

private:
	rclcpp::TimerBase::SharedPtr landing_timer_;
	rclcpp::Publisher<OffboardControlMode>::SharedPtr offboard_control_mode_publisher_;
	rclcpp::Publisher<TrajectorySetpoint>::SharedPtr trajectory_setpoint_publisher_;
	rclcpp::Publisher<VehicleCommand>::SharedPtr vehicle_command_publisher_;
	rclcpp::Subscription<VehicleOdometry>::SharedPtr vehicle_odometry_subscriber_;

	std::atomic<uint64_t> timestamp_; //!< common synced timestamped
	float current_altitude_ = 0.0; //!< Current altitude in meters, updated from vehicle odometry

	void publish_offboard_control_mode();
	void publish_trajectory_setpoint(float altitude);
	void publish_vehicle_command(uint16_t command, float param1 = 0.0, float param2 = 0.0);
};

void OffboardControl::arm()
{
	publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0);
	RCLCPP_INFO(this->get_logger(), "Arm command sent");
}

void OffboardControl::disarm()
{
	publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 0.0);
	RCLCPP_INFO(this->get_logger(), "Disarm command sent");
}

void OffboardControl::publish_offboard_control_mode()
{
	OffboardControlMode msg{};
	msg.position = true;
	msg.velocity = false;
	msg.acceleration = false;
	msg.attitude = false;
	msg.body_rate = false;
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	offboard_control_mode_publisher_->publish(msg);
}

void OffboardControl::publish_trajectory_setpoint(float altitude)
{
	TrajectorySetpoint msg{};
	msg.position = {0.0, 0.0, altitude};
	msg.yaw = 3.14; // Yaw angle [-PI:PI]
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	trajectory_setpoint_publisher_->publish(msg);
}

void OffboardControl::publish_vehicle_command(uint16_t command, float param1, float param2)
{
	VehicleCommand msg{};
	msg.param1 = param1;
	msg.param2 = param2;
	msg.command = command;
	msg.target_system = 1;
	msg.target_component = 1;
	msg.source_system = 1;
	msg.source_component = 1;
	msg.from_external = true;
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	vehicle_command_publisher_->publish(msg);
}

void OffboardControl::smooth_landing()
{
	if (current_altitude_ < -0.1) // Continue landing if altitude is above ground
	{
		current_altitude_ += 0.5; // Increase altitude incrementally (descending smoothly)
		publish_trajectory_setpoint(current_altitude_);
		RCLCPP_INFO(this->get_logger(), "Landing in progress, altitude: %.2f", current_altitude_);
	}
	else
	{
		RCLCPP_INFO(this->get_logger(), "Landing complete. Disarming...");
		disarm();
		landing_timer_->cancel(); // Stop the timer after landing
	}
}

int main(int argc, char *argv[])
{
	std::cout << "Starting offboard control node..." << std::endl;
	setvbuf(stdout, NULL, _IONBF, BUFSIZ);
	rclcpp::init(argc, argv);
	auto node = std::make_shared<OffboardControl>();

	node->arm();
	rclcpp::spin(node);

	rclcpp::shutdown();
	return 0;
}
