#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from px4_msgs.msg import VehicleOdometry, VehicleLocalPosition
import pandas as pd

class PX4DataLogger(Node):
    def __init__(self):
        super().__init__('px4_data_logger')

        # QoS Profile untuk kompatibilitas dengan PX4
        qos_profile = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, depth=10)

        # Subscriber untuk data aktual
        self.create_subscription(VehicleOdometry, '/fmu/out/vehicle_odometry', self.actual_odometry_callback, qos_profile)
        # Subscriber untuk data setpoint dari /circle_trajectory
        self.create_subscription(VehicleLocalPosition, '/circle_trajectory', self.setpoint_odometry_callback, qos_profile)
        
        # Variabel penyimpanan data
        self.clock_time = None
        self.actual_position = (0.0, 0.0, 0.0)
        self.actual_velocity = (0.0, 0.0, 0.0, 0.0)
        self.actual_yaw = 0.0
        self.setpoint_position = (0.0, 0.0, 0.0)

        # List untuk menyimpan data
        self.data_list = []

    def actual_odometry_callback(self, msg: VehicleOdometry):
        self.clock_time = msg.timestamp / 1e6  # Convert microseconds to seconds
        self.actual_position = (msg.position[0], msg.position[1], msg.position[2])
        self.actual_yaw = msg.q[2] if len(msg.q) > 2 else 0.0  # Ambil yaw dari quaternion
        self.actual_velocity = (msg.velocity[0], msg.velocity[1], msg.velocity[2], msg.angular_velocity[2])
        self.log_data()

    def setpoint_odometry_callback(self, msg: VehicleLocalPosition):
        # Ambil setpoint dari VehicleLocalPosition
        self.setpoint_position = (msg.x, msg.y, msg.z)

    def log_data(self):
        if self.clock_time is not None:
            xref, yref, zref = self.setpoint_position
            x, y, z = self.actual_position
            yaw = self.actual_yaw
            vx, vy, vz, vyaw = self.actual_velocity

            # Simpan dalam list
            self.data_list.append([self.clock_time, xref, x, yref, y, zref, z, yaw, vx, vy, vz, vyaw])

            # Log ke console
            self.get_logger().info(f"Time: {self.clock_time:.3f}, Setpoint: ({xref:.3f}, {yref:.3f}, {zref:.3f}), Actual: ({x:.3f}, {y:.3f}, {z:.3f}), Yaw: {yaw:.3f}, Velocities: ({vx:.3f}, {vy:.3f}, {vz:.3f}, {vyaw:.3f})")

    def save_to_excel(self):
        if self.data_list:
            df = pd.DataFrame(self.data_list, columns=["Time(s)", "xref", "x", "yref", "y", "zref", "z", "yaw", "vx", "vy", "vz", "vyaw"])
            df.to_excel('px4_data.xlsx', index=False)

    def run(self):
        while rclpy.ok():
            rclpy.spin_once(self)

    def save_remaining_data(self):
        self.save_to_excel()


def main(args=None):
    rclpy.init(args=args)
    node = PX4DataLogger()
    try:
        node.run()
    finally:
        node.save_remaining_data()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
