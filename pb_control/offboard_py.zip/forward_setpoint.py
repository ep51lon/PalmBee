#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from px4_msgs.msg import TrajectorySetpoint, VehicleOdometry
import math

class OffboardControl(Node):
    def __init__(self):
        super().__init__('offboard_control')

        # Inisialisasi publisher untuk trajectory setpoint
        self.trajectory_setpoint_publisher = self.create_publisher(TrajectorySetpoint, '/fmu/in/trajectory_setpoint', 10)

        # Subscriber untuk mendapatkan data vehicle odometry
        self.vehicle_odometry_subscriber = self.create_subscription(
            VehicleOdometry, '/fmu/in/vehicle_visual_odometry', self.vehicle_odometry_callback, 10)

        # Variabel untuk kontrol gerakan linear
        self.offboard_setpoint_counter = 0

        # Koordinat x, y, z
        self.x = 0.0
        self.y = 5.0  # Posisi Y tetap
        self.z = -5.0  # Posisi Z tetap

        # Timer untuk memanggil callback setiap 100ms
        self.timer = self.create_timer(0.1, self.timer_callback)

    def vehicle_odometry_callback(self, msg):
        # Mendapatkan posisi x dan y dari vehicle visual odometry
        # Pastikan posisi yang diterima valid (bukan NaN)
        if not math.isnan(msg.position[0]) and not math.isnan(msg.position[1]):
            self.x = msg.position[0]
            self.y = msg.position[1]
            self.get_logger().info(f'Updated position - X: {self.x}, Y: {self.y}')

    def timer_callback(self):
        # Publish trajectory (gerakan maju) setiap 100ms
        self.publish_trajectory_setpoint()

        # Stop the counter after reaching 11
        if self.offboard_setpoint_counter < 11:
            self.offboard_setpoint_counter += 1

    def publish_trajectory_setpoint(self):
        # Membuat pesan trajectory setpoint
        msg = TrajectorySetpoint()
        msg.position = [float(self.x), float(self.y), float(self.z)]  # Posisi X, Y, Z
        msg.yaw = float('nan')  # Mengatur yaw agar tetap di arah yang sama (0 radian)
        msg.timestamp = self.get_clock().now().nanoseconds // 1000  # Timestamp dalam mikrodetik

        # Publikasikan pesan
        self.trajectory_setpoint_publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    offboard_control = OffboardControl()
    rclpy.spin(offboard_control)
    offboard_control.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
