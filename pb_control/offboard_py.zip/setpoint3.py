#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped
import random

class TargetPositionPublisher(Node):
    def __init__(self):
        super().__init__('target_position_publisher')
        self.publisher_ = self.create_publisher(PointStamped, '/palmbee/tree/target_position', 10)
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz (every 0.05 seconds)

    def timer_callback(self):
        msg = PointStamped()

        # Set header
        now = self.get_clock().now().to_msg()
        msg.header.stamp = now
        msg.header.frame_id = "map"  # Optional: depends on your TF or visualization setup

        # Generate target position
        x = 0.0    # Fixed X value
        y = 10.0   # Fixed Y value
        z = -3.0    # Example Z value (can be changed)

        msg.point.x = x
        msg.point.y = y
        msg.point.z = z

        # Publish the message
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing PointStamped: x={x}, y={y}, z={z}')

def main(args=None):
    rclpy.init(args=args)
    node = TargetPositionPublisher()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
