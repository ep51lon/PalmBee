from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='rtabmap_ros',
            executable='rtabmap',
            name='rtabmap',
            output='screen',
            remappings=[
                ('rgb/image', '/camera'),
                ('rgb/camera_info', '/camera_info'),
            ],
            parameters=[{
                'frame_id': 'base_link',
                'subscribe_depth': False,
                'subscribe_rgbd': False,
                'approx_sync': True,
            }]
        )
    ])
