#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped
from px4_msgs.msg import TrajectorySetpoint

class GoingHome(Node):
    def __init__(self):
        super().__init__('going_home')

        # Publisher ke PX4
        self.trajectory_setpoint_publisher = self.create_publisher(
            TrajectorySetpoint,
            '/fmu/in/trajectory_setpoint',
            10
        )

        # Subscriber ke topik home setpoint
        self.create_subscription(
            PointStamped,
            '/palmbee/home_setpoint',
            self.publish_home_trajectory,
            10
        )

    def publish_home_trajectory(self, msg):
        """Publish posisi dari home_setpoint ke PX4 dalam format TrajectorySetpoint."""
        x = msg.point.x
        y = msg.point.y
        z = msg.point.z

        self.get_logger().info(f"Going home to: x={x}, y={y}, z={z}")

        msg_trajectory = TrajectorySetpoint()
        msg_trajectory.position = [float(x), float(y), float(z)]
        msg_trajectory.yaw = float('nan')
        msg_trajectory.timestamp = self.get_clock().now().nanoseconds // 1000

        self.trajectory_setpoint_publisher.publish(msg_trajectory)

def main(args=None):
    rclpy.init(args=args)
    node = GoingHome()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
