#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from px4_msgs.msg import ManualControlSetpoint, OffboardControlMode, VehicleCommand
from std_msgs.msg import Header
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

class ManualControlPublisher(Node):
    def __init__(self):
        super().__init__('manual_control_publisher')

        # Configure QoS profile for publishing
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        # Create publishers
        self.publisher = self.create_publisher(ManualControlSetpoint, '/fmu/in/manual_control_input', 10)
        self.offboard_control_mode_publisher = self.create_publisher(OffboardControlMode, '/fmu/in/offboard_control_mode', qos_profile)
        self.vehicle_command_publisher = self.create_publisher(VehicleCommand, '/fmu/in/vehicle_command', qos_profile)

        # Create a timer to publish control commands
        self.timer = self.create_timer(0.1, self.timer_callback)  # Publish setiap 0.1 detik
        self.setpoint = ManualControlSetpoint()

        # Set the counter for offboard mode and arming
        self.offboard_setpoint_counter = 0

    def arm(self):
        """Send an arm command to the vehicle."""
        msg = VehicleCommand()
        msg.command = VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM
        msg.param1 = 1.0  # Arm the vehicle
        msg.timestamp = int(self.get_clock().now().nanoseconds / 1000)
        self.vehicle_command_publisher.publish(msg)
        self.get_logger().info('Arm command sent')

    def engage_offboard_mode(self):
        """Switch to offboard mode."""
        msg = VehicleCommand()
        msg.command = VehicleCommand.VEHICLE_CMD_DO_SET_MODE
        msg.param1 = 1.0  # Set system to use mode
        msg.param2 = 6.0  # Offboard mode ID
        msg.timestamp = int(self.get_clock().now().nanoseconds / 1000)
        self.vehicle_command_publisher.publish(msg)
        self.get_logger().info('Switching to offboard mode')

    def publish_offboard_control_heartbeat_signal(self):
        """Publish the offboard control mode."""
        msg = OffboardControlMode()
        msg.position = True
        msg.velocity = False
        msg.acceleration = False
        msg.attitude = False
        msg.body_rate = False
        msg.timestamp = int(self.get_clock().now().nanoseconds / 1000)
        self.offboard_control_mode_publisher.publish(msg)

    def timer_callback(self):
        """Callback function for the timer."""
        self.publish_offboard_control_heartbeat_signal()

        if self.offboard_setpoint_counter == 0:
            self.engage_offboard_mode()
            self.arm()
            self.offboard_setpoint_counter += 1

        # Set the manual control setpoint for throttle, roll, pitch, yaw
        self.setpoint.timestamp = int(self.get_clock().now().nanoseconds / 1000)  # Timestamp dalam microseconds
        self.setpoint.timestamp_sample = self.setpoint.timestamp  # Sampel timestamp
        self.setpoint.valid = True

        # Menetapkan nilai stick dan throttle
        self.setpoint.roll = 0.0    # Tidak ada pergerakan pada roll (sumbu X)
        self.setpoint.pitch = 0.0   # Tidak ada pergerakan pada pitch (sumbu Y)
        self.setpoint.yaw = 0.0     # Tidak ada pergerakan pada yaw (sumbu Z)
        self.setpoint.throttle = 0.5 # Throttle setengah (gerakan naik 50%)
        
        # Aux input dan tombol
        self.setpoint.flaps = 0.0
        self.setpoint.aux1 = 0.0
        self.setpoint.aux2 = 0.0
        self.setpoint.aux3 = 0.0
        self.setpoint.aux4 = 0.0
        self.setpoint.aux5 = 0.0
        self.setpoint.aux6 = 0.0
        self.setpoint.sticks_moving = False
        self.setpoint.buttons = 0

        # Publikasi ke topik
        self.publisher.publish(self.setpoint)

def main(args=None):
    rclpy.init(args=args)
    node = ManualControlPublisher()
    rclpy.spin(node)

if __name__ == '__main__':
    main()