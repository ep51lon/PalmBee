#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from px4_msgs.msg import VehicleOdometry, TimesyncStatus
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import numpy as np

class PoseToOdometry(Node):
    def __init__(self):
        super().__init__('pose_to_vo')

        # Subscription untuk Visual Odometry dari kamera (default QoS Reliable sudah cocok)
        self.subscription = self.create_subscription(
            PoseStamped,
            '/gui/camera/pose',
            self.pose_callback,
            10)

        # Publisher untuk VO ke PX4
        self.vo_publisher = self.create_publisher(
            VehicleOdometry,
            '/fmu/in/vehicle_visual_odometry',
            10)

        # Subscription untuk Timesync dari PX4 (menggunakan QoS BEST_EFFORT)
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        self.timesync_sub = self.create_subscription(
            TimesyncStatus,
            '/fmu/out/timesync_status',
            self.timesync_callback,
            qos_profile
        )

        self.px4_timestamp = 0

    def timesync_callback(self, msg):
        self.px4_timestamp = msg.timestamp  # mikrodetik dari PX4

    def pose_callback(self, msg):
        vo_msg = VehicleOdometry()

        # Gunakan timestamp PX4
        vo_msg.timestamp = self.px4_timestamp
        vo_msg.timestamp_sample = self.px4_timestamp

        # Transformasi koordinat (FLU Kamera ke FLD PX4)
        vo_msg.position = [
            float(msg.pose.position.y),
            float(msg.pose.position.x),
            float(-msg.pose.position.z),
        ]

        vo_msg.q = [
            float(msg.pose.orientation.w),
            float(msg.pose.orientation.y),
            float(msg.pose.orientation.x),
            float(-msg.pose.orientation.z),
        ]

        vo_msg.pose_frame = VehicleOdometry.POSE_FRAME_NED
        vo_msg.velocity_frame = VehicleOdometry.VELOCITY_FRAME_UNKNOWN
        vo_msg.velocity = [np.nan, np.nan, np.nan]
        vo_msg.angular_velocity = [np.nan, np.nan, np.nan]
        vo_msg.position_variance = [np.nan, np.nan, np.nan]
        vo_msg.orientation_variance = [np.nan, np.nan, np.nan]
        vo_msg.velocity_variance = [np.nan, np.nan, np.nan]
        vo_msg.reset_counter = 0
        vo_msg.quality = 100

        self.vo_publisher.publish(vo_msg)

def main(args=None):
    rclpy.init(args=args)
    node = PoseToOdometry()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
