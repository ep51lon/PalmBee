#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import subprocess
import time
import signal
import sys

class ScriptRunnerNode(Node):
    def __init__(self):
        super().__init__('script_runner_node')
        
        # Menyimpan subprocess yang dijalankan
        self.processes = []

        # Menjalankan ketiga script secara berurutan
        self.run_scripts()

    def run_scripts(self):
        # Menjalankan script offboard_control.py
        self.get_logger().info('Starting offboard_control.py...')
        takeoff_process = subprocess.Popen(['python3', '/home/ep51lon/polinasi_ws/src/px4_ros_com/src/examples/offboard_py/offboard_control.py'])
        #self.processes.append(subprocess.Popen(['python3', '/home/ep51lon/polinasi_ws/src/px4_ros_com/src/examples/offboard_py/offboard_control.py']))
        self.processes.append(takeoff_process)
        time.sleep(12)  # Tunggu sebentar sebelum melanjutkan

        # Menjalankan script forward.py
        self.get_logger().info('Starting forward.py...')
        forward_process = subprocess.Popen(['python3', '/home/ep51lon/polinasi_ws/src/px4_ros_com/src/examples/offboard_py/forward.py'])
        self.processes.append(forward_process)
        
        # Menjalankan script setpoint.py
        self.get_logger().info('Starting setpoint.py...')
        setpoint_process = subprocess.Popen(['python3', '/home/ep51lon/polinasi_ws/src/px4_ros_com/src/examples/offboard_py/setpoint.py'])
        self.processes.append(setpoint_process)
        
        # Tunggu beberapa detik sebelum menghentikan forward.py
        time.sleep(10) # Jalankan 10 detik
        self.get_logger().info('Stopping forward.py...')
        forward_process.terminate()  # Menghentikan forward.py
        
        # Menunggu sebentar setelah menghentikan forward.py
        time.sleep(3)

        # Menjalankan script circle.cpp menggunakan ros2 run
        self.get_logger().info('Starting circle.cpp...')
        circle_process = subprocess.Popen(['ros2', 'run', 'px4_ros_com', 'circle'])
        self.processes.append(circle_process)
        #self.processes.append(subprocess.Popen(['ros2', 'run', 'px4_ros_com', 'circle']))
        time.sleep(2) # Jalankan setpoint.py selama 2 detik
        self.get_logger().info('Stopping setpoint.py...')
        setpoint_process.terminate() # Menghentikan setpoint.py
        
        time.sleep(35) # Menunggu sebentar ketika mau menuju ke setpoint berikutnya (setpoint2.py)
        
        # Menuju setpoint 2 (setpoint2.py)
        self.get_logger().info('Starting setpoint2.py...')
        setpoint_process = subprocess.Popen(['python3', '/home/ep51lon/polinasi_ws/src/px4_ros_com/src/examples/offboard_py/setpoint2.py'])
        self.processes.append(setpoint_process)
        time.sleep(2) # Jalankan setpoint2.py selama 2 detik
        self.get_logger().info('Stopping setpoint2.py...')
        setpoint_process.terminate() # Menghentikan setpoint2.py
        
        time.sleep(35) # Menunggu sebentar ketika mau menuju ke setpoint berikutnya (setpoint3.py)
        
        # Menuju setpoint 3 (setpoint3.py)
        self.get_logger().info('Starting setpoint3.py...')
        setpoint_process = subprocess.Popen(['python3', '/home/ep51lon/polinasi_ws/src/px4_ros_com/src/examples/offboard_py/setpoint3.py'])
        self.processes.append(setpoint_process)
        time.sleep(2) # Jalankan setpoint3.py selama 2 detik
        self.get_logger().info('Stopping setpoint3.py...')
        setpoint_process.terminate() # Menghentikan setpoint3.py
        
        time.sleep(40) # Menunggu sebentar ketika mau menuju ke setpoint berikutnya (home_setpoint.py)
        
        circle_process.terminate() # Menghentikan circle.cpp
        
        time.sleep(3)
        
        # Menjalankan script going_home.py
        self.get_logger().info('Starting going_home.py...')
        going_home_process = subprocess.Popen(['python3', '/home/ep51lon/polinasi_ws/src/px4_ros_com/src/examples/offboard_py/going_home.py'])
        self.processes.append(going_home_process)
        
        # Menjalankan script home_setpoint.py
        self.get_logger().info('Starting home_setpoint.py...')
        home_setpoint_process = subprocess.Popen(['python3', '/home/ep51lon/polinasi_ws/src/px4_ros_com/src/examples/offboard_py/home_setpoint.py'])
        self.processes.append(home_setpoint_process)
        #time.sleep(2) # Jalankan home_setpoint.py selama 2 detik
        #self.get_logger().info('Stopping home_setpoint.py...')
        #setpoint_process.terminate() # Menghentikan home_setpoint.py
        
        #time.sleep(2) # Jeda sebelum mematikan going_home.py
        
        #going_home_process.terminate() # Mematikan going_home.py
        
        #time.sleep(5) # Jeda sebelum mematikan takeoff (offboard_control.py)
        
        #takeoff_process.terminate() # Mematikan perintah takeoff (offboard_control.py)
        
    def terminate_processes(self):
        # Fungsi untuk menghentikan semua subprocess yang berjalan
        self.get_logger().info('Terminating all processes...')
        for process in self.processes:
            process.terminate()  # Menghentikan subprocess
        sys.exit(0)

def main(args=None):
    rclpy.init(args=args)
    node = ScriptRunnerNode()

    # Menangani sinyal SIGINT (Ctrl+C) untuk menghentikan node dan subprocess
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.terminate_processes()

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
